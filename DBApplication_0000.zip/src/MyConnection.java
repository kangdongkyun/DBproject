import java.sql.Connection;

public class MyConnection {
	public static Connection con;
	
	public static Connection makeConnection() {
		
		return con;
	}
}
